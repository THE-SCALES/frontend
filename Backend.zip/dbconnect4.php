<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>musiclistへのアクセス</title>
</head>

<body>
<?php
	$db = mysqli_connect('localhost', 'next', 'nextpass', 'musiclist') or die(mysqli_connect_error());
	mysql_set_charset($db, 'utf8');
?>
</body>
</html>