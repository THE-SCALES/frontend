-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `musiclist`;
CREATE TABLE `musiclist` (
  `music` varchar(50) DEFAULT NULL,
  `index` varchar(5) NOT NULL,
  `version` enum('NEW','OLD') DEFAULT NULL,
  `basr` tinyint(2) DEFAULT '1',
  `batv` smallint(4) DEFAULT '1',
  `mesr` tinyint(2) DEFAULT '1',
  `metv` smallint(4) DEFAULT '1',
  `hasr` tinyint(2) DEFAULT '1',
  `hatv` smallint(4) DEFAULT '1',
  `spsr` tinyint(2) DEFAULT '1',
  `sptv` smallint(4) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2016-11-10 23:50:33
