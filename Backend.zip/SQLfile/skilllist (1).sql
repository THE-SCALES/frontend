-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE TABLE `skilllist` (
  `id` int(11) NOT NULL DEFAULT '0',
  `music` varchar(50) DEFAULT NULL,
  `difficulty` varchar(7) DEFAULT NULL,
  `skillrate` tinyint(2) DEFAULT '1',
  `skillpoint` float DEFAULT '1',
  `score` smallint(4) DEFAULT '1',
  `scorerate` float DEFAULT '1',
  `max` float DEFAULT '1',
  `comment` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2016-11-10 23:54:29
