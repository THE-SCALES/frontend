<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>usersデータベースへのアクセス</title>
</head>

<body>
<?php
	$db = mysqli_connect('localhost', 'next', 'nextpass', 'users') or die(mysqli_connect_error());
	mysql_set_charset($db, 'utf8');
?>
</body>
</html>