<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>skilllistデータベースへのアクセス</title>
</head>

<body>
<?php
	$db = mysqli_connect('localhost', 'next', 'nextpass', 'skilllist') or die(mysqli_connect_error());
	mysql_set_charset($db, 'utf8');
?>
</body>
</html>