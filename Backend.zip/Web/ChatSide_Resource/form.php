<?php
require 'connect_db.php';
require 'util.php';
?>
<!DOCTYPE html>
<html lang="ja-JP">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-JP">
<link rel="STYLESHEET" TITLE="default" TYPE="text/css" href="./bbs.css">
<?php
if (!isset($_GET["boardid"])) {
  die('URL���ѤǤ���');
 }
 $board_id=$_GET["boardid"];
 $board_name = get_board_name($board_id);
 
 if (isset($_GET["parent"])) {
  $parent = $_GET["parent"];
   if (!ctype_digit($parent)) {
    die("ï�˥쥹����Ĥ��ʤ����");
  }
   $sql_str = sprintf("select * from message where boardid='%s' and serialid=%d",
                   $board_id, $parent);
  $result = mysql_query_or_die($sql_str);
  if (mysql_num_rows($result) != 1) {
     die("ï�˥쥹���Ƥ�Ĥ��ʤ��������");
   }
 $row = mysql_fetch_assoc($result);
 $parent_subject=$row["subject"];
 $parent_message=$row["message"];
 }
?>
<TITLE><?=$board_name?>����ƥե�����</TITLE>
<script language="JavaScript">
<!--
   function get_cookie(key) {
   var i, index, splitted;
   var sstr = key + "=";
   var sstrlen = sstr.length;
   splitted = document.cookie.split("; ");
 
   for(i = 0; i < splitted.length; i++) {
     if (splitted[i].substring(0, sstrlen) == sstr) {
       return unescape(splitted[i].substring(sstrlen));
      }
    }
     return "";
   }
   function set_cookie(key, val) {
     document.cookie =
     key + "=" + escape(val) + "; expires=Wed, 01-Jan-2031 00:00:00 GMT;";
   }
 function set_cookies() {
     set_cookie("name", document.mainForm.name.value);
     set_cookie("url", document.mainForm.url.value);
     set_cookie("password", document.mainForm.password.value);
   }
//-->
</script>
 </head>
 <body>
<table><tr><td align="center">
  <font size="6" color="#0000ff"><?=$board_name?>����ƥե�����</font><br>
  <hr>
  <CENTER>
   <FONT color="red" size="4">����!!</FONT><BR>
   ���ηǼ��ĤǤϡ���ǲ��Ԥ�����ʤ��¤���Ԥ���ޤ���<BR>
   <SMALL>(��������Ž��Ȥ��Τ����PRE�ǰϤि��)</SMALL><BR>
   Ŭ���ʾ��ǲ��Ԥ�����Ƥ���������<BR>
   <a href="http://kmaebashi.com/bbshelp.html">�إ��</a>
  </CENTER>
   <form name="mainForm" action="preview.php" method="post">
   <input type="hidden" name="boardid" value="<?=htmlspecialchars($board_id)?>">
 <?php
   if (isset($parent)) {
 ?>
   <input type="hidden" name="parent" value="<?=$parent?>">
 <?php
   }
 ?>
  <table border="1">
    <tr>
      <td>�ϥ�ɥ�̾</td>
     <td><input type="text" name="name" size="40"></td>
    </tr>
    <tr>
      <td>��̾</td>
     <td><input type="text" name="subject"
 <?php
  if (isset($parent)) {
  if (ereg('^Re:.*$', $parent_subject)) {
      $new_subject = $parent_subject;
    } else {
       $new_subject = "Re:" . $parent_subject;
    }
 ?>
         value="<?=$new_subject?>"
 <?php
   }
 ?>
          size="40"></td>
   </tr>
   <tr>
     <td>Link</td>
          <td><input type="text" name="url" size="40"></td>
    </tr>
 </table>
 <table>
  <tr><td>
<textarea name="message" cols="80" rows="20">
<?php
 if (isset($parent)) {
?>
<?=get_parent_message($parent_message)?>
 <?php
  }
 ?>
 </textarea>
  </td></tr>
  </table>
  <table><tr>
    <td>����ѥ���� : <input type="text" name="password" size="12"></td>
   <td width="30"></td>
    <td><input type="submit" value="����" onClick="set_cookies();"></td>
   </tr></table>
  </form>
 </td></tr></table></div>
  <script language="JavaScript">
 <!--
  document.mainForm.name.value = get_cookie("name");
  document.mainForm.url.value = get_cookie("url");
  document.mainForm.password.value = get_cookie("password");
  //-->
  </script>
  
 </body>
 </html>