 <?php
 require '../connect_chatdb.php';
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=EUC-JP">
 <link rel="STYLESHEET" TITLE="default" TYPE="text/css" href="./admin.css">
 <title>����������åȤκ���</title>
 </head>
 <body>
 <?php
 if ($_POST["boardname"] == ""
     || $_POST["boardid"] == ""
     || $_POST["defaultrange"] == ""
     || $_POST["defaultrangeindex"] == ""
     || $_POST["defaultrangethread"] == ""
     || $_POST["homepage"] == ""
     || $_POST["css"] == ""
     || $_POST["showmessagephp"] == "" ) {
   die("���Ƥι��ܤ����Ϥ��Ƥ�������");
 }
 $sql_str = "insert into board (name, boardid, defaultrange, defaultrangeindex, "
            . "defaultrangethread, "
            . "homepage, css, showmessagephp) ";
 $sql_str .= sprintf("values ('%s', '%s', %d, %d, %d, '%s', '%s', '%s')",
                     $_POST["boardname"],
                     $_POST["boardid"],
                     $_POST["defaultrange"],
                     $_POST["defaultrangeindex"],
                     $_POST["defaultrangethread"],
                     $_POST["homepage"],
                     $_POST["css"],
                     $_POST["showmessagephp"]);
 mysql_query($sql_str, $dbh)
   or die('SQL���顼..'.$sql_str);
?>
<p>
  ����åȡ�
 <?= htmlspecialchars(stripslashes($_POST["boardname"]))?>
 �פκ�������λ���ޤ�����
</p>
</body>
</html>