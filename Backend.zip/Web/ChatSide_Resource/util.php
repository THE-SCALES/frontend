<?php
function format_date($src) {
   $ret = substr($src, 0, 4) . "/" . substr($src, 4, 2) . "/" . substr($src, 6, 2)
            . " " . substr($src, 8, 2) . ":" . substr($src, 10, 2) . ":"
            . substr($src, 12, 2);
 
   return $ret;
 }
 
 function is_positive_number($str) {
   if (!ctype_digit($str)) {
     return false;
   }
   if ($str <= 0) {
     return false;
   }
 
   return true;
 }
 
 function get_parent_message($src) {
   $dest=htmlspecialchars($src);
   $dest=ereg_replace('^', '&gt;' ,$dest);
   $dest=ereg_replace("\n", "\n>" ,$dest);
   return $dest;
 }
 
 function convert_message($src) {
   $dest = ereg_replace("http://[^<>[:space:]]+[[:alnum:]/]",
                        "<a href=\"\\0\">\\0</a>", $src);
   return $dest;
 }
 
 function mysql_query_or_die($sql_str) {
   $result = mysql_query($sql_str) or die('SQLエラー'.$sql_str);
 
   return $result;
 }
 
 function get_board_name($board_id) {
   $sql_str = sprintf("select name from board where boardid='%s'",
                      $board_id);
   $result = mysql_query_or_die($sql_str);
   if (mysql_num_rows($result) != 1) {
     die("掲示板のIDが違います");
   }
   $row = mysql_fetch_assoc($result);
   return $row["name"];
 }
 ?>