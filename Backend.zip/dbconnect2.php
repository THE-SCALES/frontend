<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>newskilllistデータベースへのアクセス</title>
</head>

<body>
<?php
	$db = mysqli_connect('localhost', 'next', 'nextpass', 'newskilllist') or die(mysqli_connect_error());
	mysql_set_charset($db, 'utf8');
?>
</body>
</html>